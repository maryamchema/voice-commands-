// lib/features/task_manager/data/services/llm_command_processor.dart

import 'package:dartz/dartz.dart' hide Task;
import 'package:task_assesment/core/errors/failures.dart';
import 'package:task_assesment/features/task_manager/domain/entities/task.dart';
import 'package:task_assesment/features/task_manager/domain/services/command_processor.dart';
import 'package:intl/intl.dart';

class LLMCommandProcessor implements CommandProcessor {
  @override
  Future<Either<Failure, CommandResult>> processCommand(String input) async {
    try {
      // Simulate LLM API call - replace with actual API call
      final parsed = _parseCommand(input);
      print("###########_______---------------$input");
      if (parsed.containsKey('action') && parsed['action'] == 'create') {
        final task = Task(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          title: parsed['title'] ?? 'New Task',
          description: parsed['description'] ?? '',
          scheduledTime: parsed['time'] ?? DateTime.now(),
        );
        return Right(CommandResult.create(task));
      } else if (parsed.containsKey('action') && parsed['action'] == 'update') {
        return Right(CommandResult.update(
          parsed['taskId'],
          parsed['newTime'],
        ));
      } else if (parsed.containsKey('action') && parsed['action'] == 'delete') {
        return Right(CommandResult.delete(parsed['taskId']));
      }

      return Left(LLMProcessingFailure('Could not understand command'));
    } catch (e) {
      return Left(LLMProcessingFailure(e.toString()));
    }
  }

  Map<String, dynamic> _parseCommand(String input) {
    // Normalize input
    input = input.toLowerCase().trim();

    // Simple keyword matching
    if (input.contains('create') || input.contains('add')) {
      return {
        'action': 'create',
        'title': _extractTitle(input) ?? 'New Task',
        'time': _extractTime(input),
      };
    } else if (input.contains('update') || input.contains('change')) {
      return {
        'action': 'update',
        'taskId': _extractTaskId(input),
        'newTime': _extractTime(input),
      };
    } else if (input.contains('delete') || input.contains('remove')) {
      return {
        'action': 'delete',
        'taskId': _extractTaskId(input),
      };
    }

    return {}; // No command recognized
  }

// Helper methods
  String? _extractTitle(String input) {
    // Remove command words
    String text =
        input.replaceAll(RegExp(r'create|add|make|task|at|on|for'), '').trim();

    // Return first 3 words as title
    return text.split(' ').take(3).join(' ').trim();
  }

  String? _extractTaskId(String input) {
    // Find the first word after command words
    final words = input.split(' ');
    final commandWords = ['update', 'change', 'delete', 'remove', 'task'];

    for (int i = 0; i < words.length; i++) {
      if (commandWords.contains(words[i])) {
        return i + 1 < words.length ? words[i + 1] : null;
      }
    }
    return null;
  }

  DateTime _extractTime(String input) {
    // Simple time patterns
    final timePatterns = [
      RegExp(r'at (\d{1,2}(?::\d{2})?\s*(?:am|pm)?)'),
      RegExp(r'on (\w+\s+\d{1,2}(?:,\s*\d{4})?)'),
    ];

    for (final pattern in timePatterns) {
      final match = pattern.firstMatch(input);
      if (match != null) {
        return _parseDateTime(match.group(1));
      }
    }
    return DateTime.now().add(Duration(hours: 1)); // Default: 1 hour from now
  }

  DateTime _parseDateTime(String? input) {
    if (input == null) return DateTime.now();

    try {
      // Try various date formats
      final formats = [
        'h:mm a on MMMM d, yyyy', // 8:50 PM on December 5, 2025
        'h:mm a MMMM d, yyyy', // 8:50 PM December 5, 2025
        'MMMM d, yyyy h:mm a', // December 5, 2025 8:50 PM
      ];

      for (final format in formats) {
        try {
          return DateFormat(format).parse(input);
        } catch (_) {}
      }

      return DateTime.now();
    } catch (e) {
      return DateTime.now();
    }
  }
}
