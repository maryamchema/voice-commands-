// lib/features/task_manager/data/services/llm_api_service.dart

import 'dart:convert';

import 'package:dio/dio.dart';

class LLMApiService {
  final Dio dio;
  final String apiKey;

  LLMApiService({required this.dio, required this.apiKey});

  Future<Map<String, dynamic>> processCommand(String input) async {
    final response = await dio.post(
      'https://api.openai.com/v1/chat/completions',
      data: {
        'model': 'gpt-3.5-turbo',
        'messages': [
          {
            'role': 'system',
            'content': '''
              You are a task management assistant. Extract:
              - action: create/update/delete
              - title: task title
              - time: DateTime in ISO format
              - taskId: for updates/deletes
              Return JSON format only.
            '''
          },
          {'role': 'user', 'content': input}
        ]
      },
      options: Options(headers: {'Authorization': 'Bearer $apiKey'}),
    );

    final content = response.data['choices'][0]['message']['content'];
    return jsonDecode(content);
  }
}
