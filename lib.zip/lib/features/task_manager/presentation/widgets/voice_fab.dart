// lib/features/task_manager/presentation/widgets/voice_fab.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:task_assesment/features/task_manager/domain/services/llm_command_processor.dart';
import 'package:task_assesment/features/task_manager/presentation/bloc/task_bloc.dart';

import '../../domain/entities/task.dart';
import '../../domain/services/command_processor.dart';

class VoiceFab extends StatefulWidget {
  const VoiceFab({super.key});

  @override
  State<VoiceFab> createState() => _VoiceFabState();
}

class _VoiceFabState extends State<VoiceFab> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isListening = false;
  String _lastWords = '';
  bool _hasFinalResult = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (_lastWords.isNotEmpty)
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              _lastWords,
              style: const TextStyle(fontSize: 16),
            ),
          ),
        FloatingActionButton(
          onPressed: _toggleRecording,
          tooltip: 'Voice Command',
          backgroundColor:
              _isListening ? Colors.red : Theme.of(context).primaryColor,
          child: Icon(_isListening ? Icons.mic_off : Icons.mic),
        ),
      ],
    );
  }

  Future<void> _toggleRecording() async {
    if (_isListening) {
      // Stop listening first
      await _speech.stop();
      setState(() => _isListening = false);

      // Wait a brief moment for final results to process
      await Future.delayed(const Duration(milliseconds: 300));

      // Only show "no command" if we never got any final results
      if (!_hasFinalResult && _lastWords.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("No voice command detected")),
        );
      }

      setState(() {
        _lastWords = '';
        _hasFinalResult = false;
      });
    } else {
      // Start new recording session
      setState(() {
        _lastWords = '';
        _hasFinalResult = false;
      });

      final available = await _speech.initialize(
        onStatus: (status) => print('Status: $status'),
        onError: (error) => print('Error: $error'),
      );

      if (available) {
        setState(() => _isListening = true);
        _speech.listen(
          onResult: (result) {
            setState(() {
              _lastWords = result.recognizedWords;
              if (result.finalResult) {
                _hasFinalResult = true;
                _processCommand(result.recognizedWords);
              }
            });
          },
          listenFor: const Duration(seconds: 5),
          cancelOnError: true,
          partialResults: true,
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Voice recognition not available")),
        );
      }
    }
  }

  // void _processCommand(String command) {
  //   if (command.trim().isEmpty) return;

  //   // Process your command here
  //   print("Processing command: $command");

  //   // Example task creation
  //   context.read<TaskBloc>().add(AddTaskEvent(
  //         Task(
  //           id: DateTime.now().millisecondsSinceEpoch.toString(),
  //           title: _extractTitle(command) ?? "New Task",
  //           description: "Created via voice command",
  //           scheduledTime: DateTime.now().add(const Duration(hours: 1)),
  //         ),
  //       ));
  // }
  Future<void> _processCommand(String command) async {
    final processor = LLMCommandProcessor();
    final result = await processor.processCommand(command);

    result.fold(
      (failure) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${failure.message}')),
        );
      },
      (result) {
        print("----------------------${result.type}");
        final bloc = context.read<TaskBloc>();
        switch (result.type) {
          case CommandType.create:
            if (result.task != null) {
              bloc.add(AddTaskEvent(result.task!));
            }
            break;
          case CommandType.update:
            if (result.taskId != null && result.newTime != null) {
              // First load current task
              bloc.add(LoadTaskByIdEvent(result.taskId!));
            }
            break;
          case CommandType.delete:
            if (result.taskId != null) {
              bloc.add(DeleteTaskEvent(result.taskId!));
            }
            break;
        }
      },
    );
  }

  String? _extractTitle(String command) {
    try {
      if (command.contains("titled")) {
        return command.split("titled").last.split(" at").first.trim();
      }
      if (command.contains("called")) {
        return command.split("called").last.split(" for").first.trim();
      }
      return command.split(" ").skip(2).take(3).join(" ");
    } catch (e) {
      return null;
    }
  }

  @override
  void dispose() {
    _speech.stop();
    super.dispose();
  }
}
