// lib/features/task_manager/presentation/widgets/task_list.dart

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:task_assesment/features/task_manager/domain/entities/task.dart';
import 'package:task_assesment/features/task_manager/presentation/bloc/task_bloc.dart';
import 'package:task_assesment/features/task_manager/presentation/widgets/task_card.dart';

// lib/features/task_manager/presentation/widgets/task_list.dart

class TaskList extends StatelessWidget {
  final List<Task> tasks;

  const TaskList({super.key, required this.tasks});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: tasks.length,
      itemBuilder: (context, index) {
        final task = tasks[index];
        return TaskCard(
          task: task,
          onDelete: () => _deleteTask(context, task.title),
          onUpdate: () => _showUpdateDialog(context, task),
        );
      },
    );
  }

  void _deleteTask(BuildContext context, String title) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Task'),
        content: Text('Are you sure you want to delete "$title"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              context.read<TaskBloc>().add(DeleteTaskByTitleEvent(title));
              Navigator.pop(context);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showUpdateDialog(BuildContext context, Task task) {
    // Your existing update dialog implementation
  }
}
